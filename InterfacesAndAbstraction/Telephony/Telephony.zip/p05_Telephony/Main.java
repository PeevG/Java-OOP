package p05_Telephony;

public class Main {
    public static void main(String[] args) {
    }
}
