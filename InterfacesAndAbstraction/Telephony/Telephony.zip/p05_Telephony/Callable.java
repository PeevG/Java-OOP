package p05_Telephony;

public interface Callable  {

    String call();
}
