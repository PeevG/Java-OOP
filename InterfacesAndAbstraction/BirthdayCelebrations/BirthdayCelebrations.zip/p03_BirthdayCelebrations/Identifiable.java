package p03_BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
