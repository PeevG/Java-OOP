package p03_BirthdayCelebrations;

public interface Person {

    String getName();
    int getAge();
}
