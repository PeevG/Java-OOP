package p03_BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
