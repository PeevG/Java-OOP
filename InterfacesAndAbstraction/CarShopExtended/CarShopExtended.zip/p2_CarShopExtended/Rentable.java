package p2_CarShopExtended;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();

}
