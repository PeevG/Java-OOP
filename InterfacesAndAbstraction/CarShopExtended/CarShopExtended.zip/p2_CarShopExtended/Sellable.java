package p2_CarShopExtended;

public interface Sellable {
    Double getPrice();
}
