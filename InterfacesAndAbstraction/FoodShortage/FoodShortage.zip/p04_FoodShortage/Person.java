package p04_FoodShortage;

public interface Person {

    String getName();
    int getAge();
}
