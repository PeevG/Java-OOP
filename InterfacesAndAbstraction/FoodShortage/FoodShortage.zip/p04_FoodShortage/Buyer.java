package p04_FoodShortage;

public interface Buyer extends Person {
    void buyFood();
    int getFood();
}
