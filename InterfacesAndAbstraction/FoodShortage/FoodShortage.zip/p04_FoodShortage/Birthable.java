package p04_FoodShortage;

public interface Birthable {
    String getBirthDate();
}
