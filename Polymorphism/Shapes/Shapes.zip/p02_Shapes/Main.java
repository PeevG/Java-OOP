package p02_Shapes;

public class Main {
    public static void main(String[] args) {

        Shape circle = new Circle(5);
        circle.calculatePerimeter();
        circle.calculateArea();
    }
}
